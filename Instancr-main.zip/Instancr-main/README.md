# Instancr

Instancr is a open-source deployment control plane for taking an AWS EC2 server from blank machine to production-ready application with strong diagnostics, structured events, and a small operational surface.

This repository currently contains the foundation only. It establishes the monorepo layout, Go command entrypoints, Next.js app placeholders, shared contracts, documentation areas, examples, GitHub templates, and CI skeleton.

## Scope

- Go for the API, server agent, CLI, scanner, doctor, cloud integration, and deployment orchestration areas.
- Next.js for `apps/site` and `apps/dashboard` only.
- AWS EC2 is the v1 infrastructure target.
- PostgreSQL, Docker, Caddy, and Server-Sent Events are future preferred infrastructure pieces.
- Apache-2.0 license for open-source use and contribution.

## Current Non-Goals

The foundation does not implement agent registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI or LLM calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud execution.

## Repository Layout

- `apps/site`: Marketing website placeholder.
- `apps/dashboard`: Product dashboard placeholder.
- `cmd/api`: Future Go API entrypoint.
- `cmd/agent`: Future Go server agent entrypoint.
- `cmd/cli`: Future Go CLI entrypoint.
- `internal`: Future private Go packages for control-plane domains.
- `pkg/contracts`: Shared public Go contracts.
- `docs`: Product, architecture, decision, and runbook notes.
- `infra`: Placeholder infrastructure folders.
- `examples`: Placeholder deployable workload examples.

## Validation

```sh
go test ./...
```

See `specs/001-foundation-monorepo/quickstart.md` for the complete foundation validation guide.
