# Roadmap

## Foundation

- Establish the monorepo layout.
- Add Go command placeholders.
- Add website and dashboard placeholders.
- Define shared contracts.
- Add contribution, security, and CI metadata.

## Future v1 Milestones

- Deterministic repository scanner.
- Diagnostic doctor checks.
- Server agent installation and lifecycle.
- AWS EC2-focused server management.
- Docker and Caddy based deployment path.
- Real-time structured event delivery.

## Explicitly Excluded From v1 Foundation

- Kubernetes, ECS, EKS, and Lambda.
- Terraform export.
- Billing.
- Multi-cloud execution.
- AI or LLM calls.
- Live AWS, Docker, or Caddy integration.
