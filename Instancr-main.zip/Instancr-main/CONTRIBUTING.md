# Contributing

Thanks for contributing to Instancr.

## Expectations

- Keep pull requests small and focused.
- Preserve the Go-first backend constraint.
- Keep Next.js changes limited to `apps/site` and `apps/dashboard`.
- Include automated tests or a documented manual validation plan.
- Update docs with behavior changes.
- Do not introduce secrets, raw tokens, or external service credentials.

## Local Validation

```sh
go test ./...
```

Run the validation scenarios in `specs/001-foundation-monorepo/quickstart.md` for foundation changes.

## Scope Guard

Do not implement agent registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud execution as part of the foundation.
