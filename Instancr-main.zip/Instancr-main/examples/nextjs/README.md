# Next.js Example

Placeholder for a future deployable user workload example.

This example is separate from `apps/site` and `apps/dashboard`.
