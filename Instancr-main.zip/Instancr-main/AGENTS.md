<!-- SPECKIT START -->
For additional context about technologies to be used, project structure,
shell commands, and other important information, read the current plan
at specs/001-foundation-monorepo/plan.md
<!-- SPECKIT END -->

Project constraints: keep backend and control-plane code in Go, keep Next.js limited to `apps/site` and `apps/dashboard`, and do not implement deployment runtime behavior in the foundation.
