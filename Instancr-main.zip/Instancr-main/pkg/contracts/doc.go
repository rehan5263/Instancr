// Package contracts defines shared Instancr data contracts.
package contracts
