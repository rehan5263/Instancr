package contracts

// AgentStatus identifies future server agent state.
type AgentStatus string

const (
	AgentStatusUnknown AgentStatus = "unknown"
	AgentStatusPending AgentStatus = "pending"
	AgentStatusOnline  AgentStatus = "online"
	AgentStatusOffline AgentStatus = "offline"
	AgentStatusError   AgentStatus = "error"
)

// Agent describes a future server agent identity and status concept.
type Agent struct {
	AgentID  string      `json:"agentId"`
	ServerID string      `json:"serverId"`
	Version  string      `json:"version,omitempty"`
	Status   AgentStatus `json:"status"`
}
