package contracts

import "time"

// EventSource identifies the component that produced an event.
type EventSource string

const (
	EventSourceControlPlane EventSource = "control_plane"
	EventSourceAgent        EventSource = "agent"
	EventSourceScanner      EventSource = "scanner"
	EventSourceDoctor       EventSource = "doctor"
)

// EventLevel identifies event severity.
type EventLevel string

const (
	EventLevelDebug EventLevel = "debug"
	EventLevelInfo  EventLevel = "info"
	EventLevelWarn  EventLevel = "warn"
	EventLevelError EventLevel = "error"
)

// EventCategory groups events by domain.
type EventCategory string

const (
	EventCategorySystem     EventCategory = "system"
	EventCategoryServer     EventCategory = "server"
	EventCategoryAgent      EventCategory = "agent"
	EventCategoryScanner    EventCategory = "scanner"
	EventCategoryDoctor     EventCategory = "doctor"
	EventCategoryDeployment EventCategory = "deployment"
)

// AgentEvent is the shared structured event contract.
type AgentEvent struct {
	Timestamp time.Time         `json:"timestamp"`
	Source    EventSource       `json:"source"`
	Level     EventLevel        `json:"level"`
	Category  EventCategory     `json:"category"`
	Code      string            `json:"code"`
	Message   string            `json:"message"`
	ServerID  string            `json:"serverId,omitempty"`
	Metadata  map[string]string `json:"metadata,omitempty"`
}
