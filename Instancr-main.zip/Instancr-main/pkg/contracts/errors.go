package contracts

// ErrorCategory identifies a machine-readable error domain.
type ErrorCategory string

const (
	ErrorCategoryValidation ErrorCategory = "validation"
	ErrorCategorySecurity   ErrorCategory = "security"
	ErrorCategoryScanner    ErrorCategory = "scanner"
	ErrorCategoryDoctor     ErrorCategory = "doctor"
	ErrorCategoryDeployment ErrorCategory = "deployment"
	ErrorCategorySystem     ErrorCategory = "system"
)

// InstancrError describes a structured, actionable failure.
type InstancrError struct {
	Code      string            `json:"code"`
	Message   string            `json:"message"`
	Category  ErrorCategory     `json:"category"`
	Retryable bool              `json:"retryable"`
	Metadata  map[string]string `json:"metadata,omitempty"`
}
