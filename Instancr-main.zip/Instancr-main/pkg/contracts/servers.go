package contracts

// ServerProvider identifies the infrastructure provider scope.
type ServerProvider string

const (
	ServerProviderAWSEC2 ServerProvider = "aws_ec2"
)

// ServerStatus identifies future managed server state.
type ServerStatus string

const (
	ServerStatusUnknown ServerStatus = "unknown"
	ServerStatusPending ServerStatus = "pending"
	ServerStatusReady   ServerStatus = "ready"
	ServerStatusError   ServerStatus = "error"
)

// Server describes a future managed server concept.
type Server struct {
	ServerID    string         `json:"serverId"`
	DisplayName string         `json:"displayName"`
	Provider    ServerProvider `json:"provider"`
	Region      string         `json:"region,omitempty"`
	Status      ServerStatus   `json:"status"`
}
