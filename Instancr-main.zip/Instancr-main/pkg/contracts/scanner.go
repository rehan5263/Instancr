package contracts

// ScanStatus identifies deterministic scan progress.
type ScanStatus string

const (
	ScanStatusPending  ScanStatus = "pending"
	ScanStatusRunning  ScanStatus = "running"
	ScanStatusComplete ScanStatus = "complete"
	ScanStatusFailed   ScanStatus = "failed"
)

// RuntimeKind identifies a detected application runtime.
type RuntimeKind string

const (
	RuntimeNodeJS RuntimeKind = "nodejs"
	RuntimeNextJS RuntimeKind = "nextjs"
	RuntimeNestJS RuntimeKind = "nestjs"
	RuntimeGo     RuntimeKind = "go"
	RuntimeOther  RuntimeKind = "other"
)

// ScanRequest describes a deterministic repository scan request.
type ScanRequest struct {
	ScanRequestID  string `json:"scanRequestId"`
	RepositoryPath string `json:"repositoryPath"`
}

// DetectedRuntime describes a runtime found during a repository scan.
type DetectedRuntime struct {
	Kind    RuntimeKind       `json:"kind"`
	Path    string            `json:"path"`
	Version string            `json:"version,omitempty"`
	Files   map[string]string `json:"files,omitempty"`
}

// ServiceRequirement describes a runtime requirement found by scanning.
type ServiceRequirement struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Required    bool   `json:"required"`
}

// ScanFinding describes a deterministic scanner finding.
type ScanFinding struct {
	Severity FindingSeverity `json:"severity"`
	Code     string          `json:"code"`
	Message  string          `json:"message"`
	Evidence string          `json:"evidence,omitempty"`
}

// ScanResult describes deterministic repository scan output.
type ScanResult struct {
	ScanRequestID       string               `json:"scanRequestId"`
	Status              ScanStatus           `json:"status"`
	DetectedRuntimes    []DetectedRuntime    `json:"detectedRuntimes,omitempty"`
	ServiceRequirements []ServiceRequirement `json:"serviceRequirements,omitempty"`
	Findings            []ScanFinding        `json:"findings,omitempty"`
}
