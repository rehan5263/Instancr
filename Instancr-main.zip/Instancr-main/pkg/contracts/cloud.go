package contracts

import "context"

// CloudProvider defines the provider boundary for infrastructure operations.
// Implementations live under internal/cloud and are consumed by deployment and
// server lifecycle code through this interface.
type CloudProvider interface {
	Provider() ServerProvider
	CreateServer(ctx context.Context, req CreateServerRequest) (*Server, error)
	GetServer(ctx context.Context, serverID string) (*Server, error)
	ListServers(ctx context.Context, opts ServerListOptions) ([]*Server, error)
	DeleteServer(ctx context.Context, serverID string) error
}

// CreateServerRequest describes a future server provisioning request.
type CreateServerRequest struct {
	DisplayName string         `json:"displayName"`
	Provider    ServerProvider `json:"provider"`
	Region      string         `json:"region,omitempty"`
	Tags        map[string]string `json:"tags,omitempty"`
}

// ServerListOptions filters a provider-backed server list.
type ServerListOptions struct {
	Provider ServerProvider `json:"provider,omitempty"`
	Region   string         `json:"region,omitempty"`
}
