package contracts

// DeploymentStatus identifies future deployment state.
type DeploymentStatus string

const (
	DeploymentStatusPending   DeploymentStatus = "pending"
	DeploymentStatusRunning   DeploymentStatus = "running"
	DeploymentStatusSucceeded DeploymentStatus = "succeeded"
	DeploymentStatusFailed    DeploymentStatus = "failed"
	DeploymentStatusCanceled  DeploymentStatus = "canceled"
)

// Deployment describes a future deployment request or status concept.
type Deployment struct {
	DeploymentID    string           `json:"deploymentId"`
	ServerID        string           `json:"serverId"`
	ApplicationName string           `json:"applicationName"`
	Status          DeploymentStatus `json:"status"`
	Events          []AgentEvent     `json:"events,omitempty"`
}
