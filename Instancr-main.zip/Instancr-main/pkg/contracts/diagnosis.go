package contracts

// FindingSeverity identifies the impact of scanner and diagnosis findings.
type FindingSeverity string

const (
	FindingSeverityInfo     FindingSeverity = "info"
	FindingSeverityWarning  FindingSeverity = "warning"
	FindingSeverityError    FindingSeverity = "error"
	FindingSeverityCritical FindingSeverity = "critical"
)

// DiagnosisStatus identifies deterministic diagnostic check status.
type DiagnosisStatus string

const (
	DiagnosisStatusPass    DiagnosisStatus = "pass"
	DiagnosisStatusWarn    DiagnosisStatus = "warn"
	DiagnosisStatusFail    DiagnosisStatus = "fail"
	DiagnosisStatusSkipped DiagnosisStatus = "skipped"
)

// DiagnosisCheck describes a deterministic diagnostic check definition.
type DiagnosisCheck struct {
	CheckID     string `json:"checkId"`
	Target      string `json:"target"`
	Description string `json:"description"`
}

// DiagnosisFinding describes deterministic diagnostic output.
type DiagnosisFinding struct {
	CheckID           string            `json:"checkId"`
	Target            string            `json:"target"`
	Status            DiagnosisStatus   `json:"status"`
	Severity          FindingSeverity   `json:"severity"`
	Code              string            `json:"code"`
	Message           string            `json:"message"`
	RecommendedAction string            `json:"recommendedAction"`
	Metadata          map[string]string `json:"metadata,omitempty"`
}
