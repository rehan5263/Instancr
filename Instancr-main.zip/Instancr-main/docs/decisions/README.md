# Decisions

Architecture decision records live here.

Changes to the constitution or major scope boundaries should be captured as formal decisions before implementation.
