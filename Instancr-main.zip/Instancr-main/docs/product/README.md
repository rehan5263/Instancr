# Product

Product notes for Instancr live here.

The current foundation defines project intent and boundaries only. Product behavior such as server enrollment, status streaming, and deployments will be specified in later features.
