# Architecture

Architecture notes and diagrams for Instancr live here.

The foundation is Go-first for control-plane code and uses Next.js only for the marketing site and dashboard placeholders.
