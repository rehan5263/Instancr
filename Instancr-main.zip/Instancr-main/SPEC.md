# Instancr Product Specification

Instancr is intended to become a lightweight open-source deployment control plane for AWS EC2 servers.

## Version 1 Direction

The v1 direction is an AWS EC2-focused system that uses deterministic scanning and diagnostics, structured event streams, and secure server-agent operations. The North Star is a blank EC2 instance to a live HTTPS application in under 5 minutes.

## Foundation Status

This repository state only creates the foundation:

- Go module and command placeholders.
- Next.js app placeholders for the site and dashboard.
- Internal package placeholders.
- Shared contracts.
- Documentation and example placeholders.
- GitHub contribution templates and CI skeleton.

## Boundaries

The foundation does not implement product workflows. It does not connect to cloud APIs, start deployments, configure Caddy, run Docker, call AI services, or manage billing.
