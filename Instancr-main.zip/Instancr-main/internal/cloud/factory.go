package cloud

import (
	"fmt"

	"github.com/instancr/instancr/internal/cloud/aws"
	"github.com/instancr/instancr/pkg/contracts"
)

// NewProvider returns a cloud provider implementation for a supported provider.
// Core deployment code should depend on the CloudProvider interface and this
// factory rather than importing provider-specific packages directly.
func NewProvider(provider contracts.ServerProvider) (contracts.CloudProvider, error) {
	switch provider {
	case contracts.ServerProviderAWSEC2:
		return aws.NewProvider(), nil
	default:
		return nil, fmt.Errorf("unsupported cloud provider %q", provider)
	}
}
