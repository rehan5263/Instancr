// Package cloud defines the provider boundary for Instancr infrastructure
// operations and isolates provider-specific implementations.
package cloud
