# internal/cloud/aws

Future private package for AWS EC2 integration.

No AWS API calls, provisioning, credentials, or infrastructure mutation behavior is implemented in the foundation.
