// Package aws contains AWS provider bindings for Instancr.
//
// The package currently exposes a skeleton AWS provider implementation
// that satisfies the CloudProvider contract and isolates AWS-specific
// dependencies from core deployment logic.
package aws
