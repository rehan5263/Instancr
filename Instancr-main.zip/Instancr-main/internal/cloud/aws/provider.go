package aws

import (
	"context"
	"errors"

	"github.com/instancr/instancr/pkg/contracts"
)

var ErrNotImplemented = errors.New("aws provider is not implemented")

type Provider struct {
	// AWS-specific configuration and client state can be added here.
}

func NewProvider() *Provider {
	return &Provider{}
}

func (p *Provider) Provider() contracts.ServerProvider {
	return contracts.ServerProviderAWSEC2
}

func (p *Provider) CreateServer(ctx context.Context, req contracts.CreateServerRequest) (*contracts.Server, error) {
	return nil, ErrNotImplemented
}

func (p *Provider) GetServer(ctx context.Context, serverID string) (*contracts.Server, error) {
	return nil, ErrNotImplemented
}

func (p *Provider) ListServers(ctx context.Context, opts contracts.ServerListOptions) ([]*contracts.Server, error) {
	return nil, ErrNotImplemented
}

func (p *Provider) DeleteServer(ctx context.Context, serverID string) error {
	return ErrNotImplemented
}
