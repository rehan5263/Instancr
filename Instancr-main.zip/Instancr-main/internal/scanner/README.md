# internal/scanner

Future private package for deterministic repository scanning.

No scanner runtime is implemented in the foundation.
