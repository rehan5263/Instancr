// Package scanner is reserved for deterministic repository scanning.
package scanner
