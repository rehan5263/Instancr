# internal/telemetry

Future private package for telemetry.

No metrics, tracing, or external telemetry export behavior is implemented in the foundation.
