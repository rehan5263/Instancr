// Package caddy is reserved for future Caddy configuration helpers.
//
// This foundation does not implement Caddy setup behavior.
package caddy
