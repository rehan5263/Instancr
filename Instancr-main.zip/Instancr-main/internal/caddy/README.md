# internal/caddy

Future private package for Caddy integration.

No Caddyfile generation, process control, or HTTPS setup behavior is implemented in the foundation.
