// Package doctor is reserved for deterministic diagnostic checks.
package doctor
