# internal/doctor

Future private package for deterministic diagnostic checks.

No diagnostic runtime is implemented in the foundation.
