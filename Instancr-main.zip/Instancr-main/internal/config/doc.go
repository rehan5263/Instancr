// Package config is reserved for future configuration loading and validation.
package config
