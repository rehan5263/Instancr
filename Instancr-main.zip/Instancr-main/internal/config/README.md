# internal/config

Future private package for configuration loading and validation.

No secrets or credential loading behavior is implemented in the foundation.
