# internal/api

Future private package for the Go API service.

No runtime API behavior is implemented in the foundation.
