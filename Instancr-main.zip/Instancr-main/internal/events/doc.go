// Package events is reserved for future structured event handling.
package events
