# internal/events

Future private package for structured event processing.

The foundation defines shared event contracts only and does not emit runtime events.
