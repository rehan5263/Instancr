# internal/database

Future private package for PostgreSQL access.

No database connection, migration, or persistence behavior is implemented in the foundation.
