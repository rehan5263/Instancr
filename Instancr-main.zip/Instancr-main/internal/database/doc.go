// Package database is reserved for future PostgreSQL integration.
package database
