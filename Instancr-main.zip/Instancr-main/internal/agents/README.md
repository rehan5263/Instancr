# internal/agents

Future private package for server agent domain logic.

No agent registration, heartbeat, token handling, or command execution behavior is implemented in the foundation.
