# internal/servers

Future private package for managed server domain logic.

No cloud lookup or server mutation behavior is implemented in the foundation.
