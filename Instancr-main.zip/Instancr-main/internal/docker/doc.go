// Package docker is reserved for future Docker orchestration helpers.
//
// This foundation does not implement Docker deployment behavior.
package docker
