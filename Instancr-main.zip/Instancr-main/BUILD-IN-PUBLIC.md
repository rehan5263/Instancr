# Build in Public

Instancr is developed as an open-source project with clear scope notes, small changes, and public documentation.

## Principles

- Prefer concrete progress notes over vague announcements.
- Make non-goals visible.
- Document architectural decisions when scope or constraints change.
- Keep early releases focused on deployment speed, diagnostics, security, and production confidence.

## Current Foundation Note

This repository state is not a working deployment product. It exists to make future implementation predictable and reviewable.
