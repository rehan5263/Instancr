# Data Model: Instancr Foundation Monorepo

## Repository Area

Represents a required folder or workspace in the monorepo.

**Fields**

- `path`: Project-relative path.
- `category`: One of app, command, internal package, public package, documentation, infrastructure, example, or GitHub metadata.
- `purpose`: Short description of the future responsibility.
- `implementation_status`: `placeholder` for this feature unless the area is documentation or shared contract definition.
- `scope_guard`: Required note when an area points to a future out-of-scope capability.

**Validation Rules**

- Every required path from the specification must exist.
- Placeholder-only areas must not include runtime integration behavior.
- Non-Go backend/control-plane services are not valid repository areas.

## Command Entrypoint

Represents a future executable under `cmd/*`.

**Fields**

- `name`: `api`, `agent`, or `cli`.
- `path`: Entrypoint directory.
- `purpose`: Future executable role.
- `status`: Placeholder for this feature.

**Validation Rules**

- Each entrypoint must compile as minimal Go code.
- Entrypoints must not implement registration, heartbeat, deployment, AWS, Docker, Caddy, AI, billing, or multi-cloud behavior.

## Shared Contract

Represents a public Go contract definition in `pkg/contracts`.

**Fields**

- `name`: Contract type name.
- `category`: event, scanner, diagnosis, server, agent, deployment, or error.
- `fields`: Stable field names required for future components.
- `validation_notes`: Constraints or required values.

**Relationships**

- AgentEvent references server identity where relevant.
- Scanner and diagnosis contracts may produce findings that use machine-readable codes.
- Deployment and error contracts share code/message concepts with AgentEvent.

## AgentEvent

Structured event emitted by future control-plane or agent actions.

**Fields**

- `timestamp`
- `source`
- `level`
- `category`
- `code`
- `message`
- `serverId`
- `metadata`

**Validation Rules**

- `code` must be machine-readable.
- `message` must be human-readable and actionable.
- `metadata` must not contain secrets, credentials, or raw tokens.

## Scanner Contract

Represents deterministic repository scan inputs and outputs.

**Fields**

- `scan_request_id`
- `repository_path`
- `detected_runtimes`
- `service_requirements`
- `findings`
- `status`

**Validation Rules**

- Scanner contracts must not require AI or LLM calls.
- Findings must include severity and machine-readable codes.

## Diagnosis Contract

Represents deterministic checks and recommendations.

**Fields**

- `check_id`
- `target`
- `status`
- `severity`
- `code`
- `message`
- `recommended_action`

**Validation Rules**

- Diagnosis output must be explainable without external AI services.
- Failure codes must be stable enough for future automation.

## Server Contract

Represents a managed server concept for future control-plane workflows.

**Fields**

- `server_id`
- `display_name`
- `provider`
- `region`
- `status`

**Validation Rules**

- Provider scope for v1 is AWS EC2 only.
- No live cloud lookup behavior is implemented in this feature.

## Agent Contract

Represents a future server agent identity or status concept.

**Fields**

- `agent_id`
- `server_id`
- `version`
- `status`

**Validation Rules**

- No registration or heartbeat behavior is implemented in this feature.
- Raw agent tokens must not appear in contracts, examples, logs, or docs.

## Deployment Contract

Represents a future deployment request or status concept.

**Fields**

- `deployment_id`
- `server_id`
- `application_name`
- `status`
- `events`

**Validation Rules**

- No Docker deployment, Caddy setup, or cloud execution behavior is implemented in this feature.
- Deployment status must be representable through structured events later.

## Error Contract

Represents machine-readable and human-readable failure details.

**Fields**

- `code`
- `message`
- `category`
- `retryable`
- `metadata`

**Validation Rules**

- `code` is required and machine-readable.
- `message` is required and actionable.
- `metadata` must not contain secrets.
