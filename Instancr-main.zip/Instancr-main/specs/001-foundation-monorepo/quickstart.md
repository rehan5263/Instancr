# Quickstart: Validate the Foundation Monorepo

Use this guide after implementation to verify the foundation without cloud credentials, deployed infrastructure, AI keys, or production secrets.

## Prerequisites

- Go latest stable installed.
- Node.js available for the two frontend app workspaces.
- Git available for repository inspection.

## 1. Confirm Required Structure

```sh
test -d apps/site
test -d apps/dashboard
test -d cmd/api
test -d cmd/agent
test -d cmd/cli
test -d internal/api
test -d internal/config
test -d internal/database
test -d internal/servers
test -d internal/agents
test -d internal/events
test -d internal/deployments
test -d internal/telemetry
test -d internal/scanner
test -d internal/doctor
test -d internal/cloud/aws
test -d internal/docker
test -d internal/caddy
test -d pkg/contracts
test -d docs/product
test -d docs/architecture
test -d docs/decisions
test -d docs/runbooks
test -d infra/docker
test -d infra/compose
test -d infra/aws
test -d examples/node-express
test -d examples/nextjs
test -d examples/nestjs-postgres
test -d .github/ISSUE_TEMPLATE
test -d .github/workflows
```

Expected outcome: every command exits successfully.

## 2. Confirm Root Documents

```sh
test -f README.md
test -f SPEC.md
test -f AGENTS.md
test -f ROADMAP.md
test -f BUILD-IN-PUBLIC.md
test -f SECURITY.md
test -f CONTRIBUTING.md
test -f LICENSE
```

Expected outcome: every command exits successfully, and `LICENSE` contains Apache-2.0 license text.

## 3. Validate Go Foundation

```sh
test -f go.mod
go test ./...
```

Expected outcome: Go packages compile and tests pass. Minimal command entrypoints under `cmd/api`, `cmd/agent`, and `cmd/cli` do not execute product workflows.

Observed on 2026-06-04: `go test ./...` passed for all Go packages; current packages have no test files.

## 4. Inspect Shared Contracts

```sh
test -d pkg/contracts
```

Expected outcome: contract files define AgentEvent, scanner, diagnosis, server, agent, deployment, and error contract categories described in [shared-contracts.md](./contracts/shared-contracts.md).

## 5. Confirm Out-of-Scope Behavior Is Absent

Search repository content for accidental implementation of excluded workflows:

```sh
rg "register|heartbeat|terraform|kubernetes|eks|ecs|lambda|openai|anthropic|llm|billing|multi-cloud|multicloud" .
```

Expected outcome: any matches are documentation, specification, roadmap, or explicit non-goal references, not runtime implementation.

Observed on 2026-06-04: matches were documentation, specification, task, quickstart, and placeholder README references only. No runtime implementation of excluded workflows was found.

## 6. Validate GitHub Collaboration Metadata

```sh
test -f .github/pull_request_template.md
test -n "$(find .github/ISSUE_TEMPLATE -maxdepth 1 -type f -print -quit)"
test -f .github/workflows/ci.yml
```

Expected outcome: pull request template, at least one issue template, and CI workflow skeleton exist.

Observed on 2026-06-04: pull request template, issue templates, and CI workflow skeleton exist.
