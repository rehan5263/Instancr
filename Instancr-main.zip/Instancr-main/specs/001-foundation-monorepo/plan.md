# Implementation Plan: Instancr Foundation Monorepo

**Branch**: `001-foundation-monorepo` | **Date**: 2026-06-04 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `specs/001-foundation-monorepo/spec.md`

## Summary

Create the initial Instancr open-source monorepo foundation with Go-first backend command entrypoints, internal domain package placeholders, Next.js website and dashboard workspaces, shared public contracts, documentation, infrastructure placeholders, examples, GitHub collaboration templates, Apache-2.0 licensing, and a CI skeleton. The plan intentionally avoids runtime product behavior such as agent registration, heartbeat, AWS calls, Docker deployment, Caddy setup, AI calls, Kubernetes-family integrations, billing, and multi-cloud support.

## Technical Context

**Language/Version**: Go latest stable for backend, CLI, scanner, doctor, cloud integration, and orchestration placeholders; Next.js/React for `apps/site` and `apps/dashboard`.

**Primary Dependencies**: Go standard library for initial placeholders and contracts; Next.js workspace dependencies for the two frontend app placeholders.

**Storage**: No runtime storage for this foundation. PostgreSQL may be documented as future direction only.

**Testing**: `go test ./...` for Go packages; frontend checks should be represented by app package scripts once initialized; CI skeleton should be able to run without cloud credentials or external secrets.

**Target Platform**: Developer workstations and CI for repository validation; future runtime target remains Linux Ubuntu/Debian-compatible AWS EC2.

**Project Type**: Open-source monorepo foundation with Go command entrypoints, public Go contract package, two frontend app workspaces, documentation, examples, and infrastructure placeholders.

**Performance Goals**: Repository validation should complete locally and in CI in under 5 minutes for the foundation state.

**Constraints**: No implemented runtime workflows for registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI/LLM calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud execution. No secrets, credentials, or raw tokens in repository content.

**Scale/Scope**: Initial foundation only; all required directories, root docs, GitHub templates, CI skeleton, command placeholders, internal package placeholders, and shared contract definitions from the spec must exist.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

- [x] **Go-First Backend**: Backend, CLI, scanner, doctor, cloud integration, and orchestration areas are planned as Go-only. Next.js is limited to `apps/site` and `apps/dashboard`.
- [x] **Deterministic-First**: The foundation does not make LLM or AI API calls and keeps scanner/diagnosis contracts deterministic.
- [x] **AWS-First Scope**: AWS content is placeholder-only for future EC2 work. No Kubernetes, ECS, EKS, Lambda, Terraform export, or multi-cloud implementation is planned.
- [x] **Structured Events**: The shared AgentEvent contract includes timestamp, source, level, category, code, message, serverId, and metadata. No executable event-emitting actions are introduced in this foundation.
- [x] **Production Confidence**: The foundation improves future delivery confidence through clear contracts, CI, docs, examples, and operational boundaries while avoiding premature runtime infrastructure behavior.
- [x] **Security First**: The plan excludes secrets and real credentials, avoids destructive server commands, and keeps deployment integrations placeholder-only.
- [x] **Open-Source Quality**: The plan includes GitHub templates, CI skeleton, Apache-2.0 licensing, documentation, and validation guidance.

## Project Structure

### Documentation (this feature)

```text
specs/001-foundation-monorepo/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── shared-contracts.md
├── checklists/
│   └── requirements.md
└── tasks.md
```

### Source Code (repository root)

```text
.
├── .github/
│   ├── ISSUE_TEMPLATE/
│   ├── pull_request_template.md
│   └── workflows/
│       └── ci.yml
├── apps/
│   ├── dashboard/
│   └── site/
├── cmd/
│   ├── agent/
│   ├── api/
│   └── cli/
├── docs/
│   ├── architecture/
│   ├── decisions/
│   ├── product/
│   └── runbooks/
├── examples/
│   ├── nestjs-postgres/
│   ├── nextjs/
│   └── node-express/
├── infra/
│   ├── aws/
│   ├── compose/
│   └── docker/
├── internal/
│   ├── agents/
│   ├── api/
│   ├── caddy/
│   ├── cloud/
│   │   └── aws/
│   ├── config/
│   ├── database/
│   ├── deployments/
│   ├── docker/
│   ├── doctor/
│   ├── events/
│   ├── scanner/
│   ├── servers/
│   └── telemetry/
├── pkg/
│   └── contracts/
├── AGENTS.md
├── BUILD-IN-PUBLIC.md
├── CONTRIBUTING.md
├── LICENSE
├── README.md
├── ROADMAP.md
├── SECURITY.md
├── SPEC.md
├── go.mod
└── package.json
```

**Structure Decision**: Use a monorepo with Go as the root control-plane module, `cmd/*` for future executables, `internal/*` for non-public domains, `pkg/contracts` for shared public Go contracts, `apps/*` for Next.js frontends, and explicit docs/infra/examples/GitHub metadata folders. Infrastructure folders are retained as placeholders only.

## Phase 0: Research

Research decisions are captured in [research.md](./research.md). All technical-context unknowns are resolved.

## Phase 1: Design & Contracts

Design artifacts:

- [data-model.md](./data-model.md): repository foundation entities, validation rules, and state expectations.
- [contracts/shared-contracts.md](./contracts/shared-contracts.md): planned public contract package shape for AgentEvent, scanner, diagnosis, server, agent, deployment, and error contracts.
- [quickstart.md](./quickstart.md): validation guide for the foundation repository after implementation.

## Post-Design Constitution Check

- [x] **Go-First Backend**: Design keeps backend/control-plane areas Go-only and restricts Next.js to the two frontend app workspaces.
- [x] **Deterministic-First**: Design has no AI calls and specifies deterministic scanner/diagnosis contract intent.
- [x] **AWS-First Scope**: Design includes placeholder AWS EC2 package/folder only and excludes live integration behavior.
- [x] **Structured Events**: Design defines the structured event contract required by the constitution.
- [x] **Production Confidence**: Design supports future deployment confidence via docs, validation, contracts, and CI skeleton without adding unsupported runtime scope.
- [x] **Security First**: Design includes no secrets and validates that foundation checks require no credentials.
- [x] **Open-Source Quality**: Design includes contributor docs, issue/PR templates, license, and repeatable validation.

## Complexity Tracking

No constitution violations require justification.
