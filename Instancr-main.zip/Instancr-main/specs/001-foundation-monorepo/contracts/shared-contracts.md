# Shared Contract Design

This feature creates initial public contract definitions in `pkg/contracts`. The implementation should use Go types and constants only; it must not introduce runtime services, network calls, persistence, deployment execution, or AI calls.

## Event Contract

**AgentEvent**

Required fields:

- `timestamp`
- `source`
- `level`
- `category`
- `code`
- `message`
- `serverId`
- `metadata`

Contract requirements:

- `code` is machine-readable.
- `message` is human-readable and actionable.
- `metadata` allows structured details but must not carry secrets, credentials, or raw tokens.

## Scanner Contracts

Required concepts:

- Scan request identifier.
- Repository path or target reference.
- Detected runtimes.
- Service requirements.
- Findings.
- Scan status.

Contract requirements:

- Scanner findings include severity, code, message, and optional evidence.
- Scanner output is deterministic and does not require AI services.

## Diagnosis Contracts

Required concepts:

- Diagnostic check identifier.
- Target under evaluation.
- Status.
- Severity.
- Machine-readable code.
- Human-readable message.
- Recommended action.

Contract requirements:

- Diagnosis findings are deterministic.
- Recommended actions are descriptive only in this foundation.

## Server, Agent, and Deployment Contracts

Required server concepts:

- Server identifier.
- Display name.
- Provider.
- Region.
- Status.

Required agent concepts:

- Agent identifier.
- Server identifier.
- Version.
- Status.

Required deployment concepts:

- Deployment identifier.
- Server identifier.
- Application name.
- Status.
- Related events.

Contract requirements:

- V1 provider language remains AWS EC2-focused.
- Agent registration, heartbeat, deployment execution, Docker deployment, and Caddy setup are not implemented in this feature.

## Error Contract

Required fields:

- `code`
- `message`
- `category`
- `retryable`
- `metadata`

Contract requirements:

- Every failure represented by the contract has a machine-readable code.
- Human-facing messages are actionable.
- Metadata must not expose secrets.

## Acceptance Mapping

- Covers FR-008 through FR-011 from the feature specification.
- Supports SC-003 by making all requested contract categories identifiable before implementation.
- Supports constitution structured-event and security requirements.
