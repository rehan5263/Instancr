# Tasks: Instancr Foundation Monorepo

**Input**: Design documents from `specs/001-foundation-monorepo/`

**Prerequisites**: [plan.md](./plan.md), [spec.md](./spec.md), [research.md](./research.md), [data-model.md](./data-model.md), [contracts/shared-contracts.md](./contracts/shared-contracts.md), [quickstart.md](./quickstart.md)

**Tests**: The feature specification does not request TDD or dedicated automated test tasks. Validation tasks are included where they prove each story independently.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel because it touches different files and has no dependency on incomplete tasks in the same phase.
- **[Story]**: Maps to a user story from [spec.md](./spec.md).
- Every task includes exact file paths.

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Initialize the repository foundation and shared workspace metadata.

- [X] T001 Initialize Go module for Instancr in `go.mod`
- [X] T002 Create root monorepo package metadata and workspace scripts in `package.json`
- [X] T003 [P] Create root ignore rules for Go, Node, local env files, and generated output in `.gitignore`
- [X] T004 [P] Create Next.js app metadata placeholder for marketing site in `apps/site/package.json`
- [X] T005 [P] Create Next.js app metadata placeholder for product dashboard in `apps/dashboard/package.json`
- [X] T006 Create minimal Go API command placeholder in `cmd/api/main.go`
- [X] T007 Create minimal Go server agent command placeholder in `cmd/agent/main.go`
- [X] T008 Create minimal Go CLI command placeholder in `cmd/cli/main.go`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Create the required empty-but-tracked monorepo areas before implementing story-specific content.

**CRITICAL**: No user story work should begin until this phase is complete.

- [X] T009 Create internal package placeholders in `internal/api/doc.go`, `internal/config/doc.go`, `internal/database/doc.go`, `internal/servers/doc.go`, `internal/agents/doc.go`, `internal/events/doc.go`, `internal/deployments/doc.go`, `internal/telemetry/doc.go`, `internal/scanner/doc.go`, and `internal/doctor/doc.go`
- [X] T010 [P] Create future integration placeholders with explicit non-implementation guards in `internal/cloud/aws/doc.go`, `internal/docker/doc.go`, and `internal/caddy/doc.go`
- [X] T011 [P] Create documentation folder placeholders in `docs/product/README.md`, `docs/architecture/README.md`, `docs/decisions/README.md`, and `docs/runbooks/README.md`
- [X] T012 [P] Create infrastructure placeholder docs with scope guards in `infra/docker/README.md`, `infra/compose/README.md`, and `infra/aws/README.md`
- [X] T013 [P] Create example workload placeholder docs in `examples/node-express/README.md`, `examples/nextjs/README.md`, and `examples/nestjs-postgres/README.md`
- [X] T014 Create shared contracts package placeholder in `pkg/contracts/doc.go`

**Checkpoint**: Required repository areas exist and are preserved in version control.

---

## Phase 3: User Story 1 - Understand the Project Foundation (Priority: P1) MVP

**Goal**: A new contributor can understand project purpose, v1 scope, non-goals, contribution expectations, security posture, roadmap, license, and build-in-public intent from root documentation.

**Independent Test**: Inspect root documentation and confirm a contributor can identify project purpose, v1 scope, non-goals, contribution process, security policy, and roadmap in under 10 minutes.

### Implementation for User Story 1

- [X] T015 [P] [US1] Write contributor-facing project overview, scope, quickstart pointers, and non-goals in `README.md`
- [X] T016 [P] [US1] Write product specification summary and v1 boundaries in `SPEC.md`
- [X] T017 [P] [US1] Preserve Spec Kit plan guidance and project agent expectations in `AGENTS.md`
- [X] T018 [P] [US1] Write public roadmap with explicit excluded platforms and future milestones in `ROADMAP.md`
- [X] T019 [P] [US1] Write build-in-public notes and communication expectations in `BUILD-IN-PUBLIC.md`
- [X] T020 [P] [US1] Write security policy covering secrets, credentials, raw agent tokens, and reporting in `SECURITY.md`
- [X] T021 [P] [US1] Write contribution guide covering small PRs, validation, docs updates, and constitution alignment in `CONTRIBUTING.md`
- [X] T022 [US1] Add Apache-2.0 license text in `LICENSE`
- [X] T023 [US1] Validate root documentation completeness against SC-001 in `specs/001-foundation-monorepo/quickstart.md`

**Checkpoint**: User Story 1 is independently complete when the root docs and license explain the project foundation without requiring source-code inspection.

---

## Phase 4: User Story 2 - Navigate Required Project Areas (Priority: P2)

**Goal**: A maintainer can verify all required monorepo areas and minimal command/app placeholders from the filesystem.

**Independent Test**: Run the structure checks in [quickstart.md](./quickstart.md) and confirm every required directory and entrypoint exists.

### Implementation for User Story 2

- [X] T024 [P] [US2] Create minimal marketing site app files in `apps/site/app/page.tsx`, `apps/site/next.config.js`, and `apps/site/tsconfig.json`
- [X] T025 [P] [US2] Create minimal product dashboard app files in `apps/dashboard/app/page.tsx`, `apps/dashboard/next.config.js`, and `apps/dashboard/tsconfig.json`
- [X] T026 [P] [US2] Document command placeholder behavior and non-goals in `cmd/api/README.md`, `cmd/agent/README.md`, and `cmd/cli/README.md`
- [X] T027 [P] [US2] Document internal package responsibilities and placeholder status in `internal/api/README.md`, `internal/config/README.md`, `internal/database/README.md`, `internal/servers/README.md`, `internal/agents/README.md`, `internal/events/README.md`, `internal/deployments/README.md`, `internal/telemetry/README.md`, `internal/scanner/README.md`, and `internal/doctor/README.md`
- [X] T028 [US2] Document future integration scope guards in `internal/cloud/aws/README.md`, `internal/docker/README.md`, and `internal/caddy/README.md`
- [X] T029 [US2] Validate project area navigation against SC-002 with filesystem checks in `specs/001-foundation-monorepo/quickstart.md`

**Checkpoint**: User Story 2 is independently complete when maintainers can verify all requested repository areas from directory listings and placeholder files.

---

## Phase 5: User Story 3 - Establish Shared Contracts (Priority: P3)

**Goal**: Future component owners can reference initial shared contracts for events, scanning, diagnosis, servers, agents, deployments, and errors.

**Independent Test**: Inspect `pkg/contracts` and confirm all contract categories from [contracts/shared-contracts.md](./contracts/shared-contracts.md) exist with typed definitions and no runtime behavior.

### Implementation for User Story 3

- [X] T030 [P] [US3] Define AgentEvent, event source, event level, and event category contracts in `pkg/contracts/events.go`
- [X] T031 [P] [US3] Define scanner request, result, runtime, service requirement, finding, and status contracts in `pkg/contracts/scanner.go`
- [X] T032 [P] [US3] Define diagnosis check, target, finding, severity, status, and recommendation contracts in `pkg/contracts/diagnosis.go`
- [X] T033 [P] [US3] Define server and agent identity/status contracts in `pkg/contracts/servers.go` and `pkg/contracts/agents.go`
- [X] T034 [P] [US3] Define deployment status and deployment event reference contracts in `pkg/contracts/deployments.go`
- [X] T035 [P] [US3] Define machine-readable error contract and retryability fields in `pkg/contracts/errors.go`
- [X] T036 [US3] Run `gofmt` on `pkg/contracts/events.go`, `pkg/contracts/scanner.go`, `pkg/contracts/diagnosis.go`, `pkg/contracts/servers.go`, `pkg/contracts/agents.go`, `pkg/contracts/deployments.go`, and `pkg/contracts/errors.go`
- [X] T037 [US3] Validate shared contract coverage against SC-003 in `specs/001-foundation-monorepo/contracts/shared-contracts.md`

**Checkpoint**: User Story 3 is independently complete when all shared contract categories exist and compile as Go types without implementing workflows.

---

## Phase 6: User Story 4 - Prepare Open-Source Collaboration Checks (Priority: P4)

**Goal**: Contributors can open issues or pull requests using templates, and maintainers have an initial CI skeleton for local repository validation.

**Independent Test**: Inspect `.github` metadata and confirm the quickstart GitHub checks pass without external credentials.

### Implementation for User Story 4

- [X] T038 [P] [US4] Create bug report issue template in `.github/ISSUE_TEMPLATE/bug_report.yml`
- [X] T039 [P] [US4] Create feature request issue template in `.github/ISSUE_TEMPLATE/feature_request.yml`
- [X] T040 [P] [US4] Create pull request checklist template in `.github/pull_request_template.md`
- [X] T041 [US4] Create CI workflow skeleton that runs foundation-safe validation in `.github/workflows/ci.yml`
- [X] T042 [US4] Validate GitHub collaboration metadata against SC-006 in `specs/001-foundation-monorepo/quickstart.md`

**Checkpoint**: User Story 4 is independently complete when issue templates, PR template, and CI workflow skeleton exist and require no cloud credentials or AI keys.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final validation and consistency across the completed foundation.

- [X] T043 Run `go test ./...` from repository root and record expected outcome in `specs/001-foundation-monorepo/quickstart.md`
- [X] T044 Verify excluded runtime workflows are absent using repository search and document any acceptable documentation-only matches in `specs/001-foundation-monorepo/quickstart.md`
- [X] T045 Review all placeholder docs for no secrets, no raw tokens, no implemented AWS/Docker/Caddy behavior, and no AI calls in `README.md`, `SECURITY.md`, `internal/cloud/aws/README.md`, `internal/docker/README.md`, `internal/caddy/README.md`, `infra/aws/README.md`, `infra/docker/README.md`, and `infra/compose/README.md`
- [X] T046 Update task completion notes or implementation deviations in `specs/001-foundation-monorepo/tasks.md`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Phase 1 Setup**: No dependencies; starts immediately.
- **Phase 2 Foundational**: Depends on Phase 1; blocks all user story work.
- **Phase 3 US1**: Depends on Phase 2; recommended MVP.
- **Phase 4 US2**: Depends on Phase 2; can run in parallel with US1 after foundation is ready.
- **Phase 5 US3**: Depends on Phase 2 and `pkg/contracts/doc.go` from T014; can run in parallel with US1 and US2 after foundation is ready.
- **Phase 6 US4**: Depends on Phase 2; can run in parallel with US1, US2, and US3 after foundation is ready.
- **Phase 7 Polish**: Depends on all desired user stories.

### User Story Dependencies

- **US1 (P1)**: No dependency on other stories after Phase 2.
- **US2 (P2)**: No dependency on US1 after Phase 2, but root docs from US1 improve navigation context.
- **US3 (P3)**: No dependency on US1 or US2 after Phase 2.
- **US4 (P4)**: No dependency on US1, US2, or US3 after Phase 2.

### Within Each User Story

- Create files before validation tasks.
- Documentation tasks can run in parallel when they touch different files.
- Contract files can be written in parallel, then formatted together.
- CI workflow should be created after root scripts and validation expectations exist.

## Parallel Opportunities

- Setup metadata tasks T003, T004, and T005 can run in parallel.
- Foundational placeholder tasks T010, T011, T012, and T013 can run in parallel after T009 starts the internal package structure.
- US1 documentation tasks T015 through T021 can run in parallel before T023 validation.
- US2 app, command, and internal docs tasks T024 through T027 can run in parallel before T029 validation.
- US3 contract definition tasks T030 through T035 can run in parallel before T036 formatting and T037 validation.
- US4 template tasks T038 through T040 can run in parallel before T041 CI workflow and T042 validation.

## Parallel Example: User Story 1

```text
Task: "T015 [P] [US1] Write contributor-facing project overview, scope, quickstart pointers, and non-goals in README.md"
Task: "T018 [P] [US1] Write public roadmap with explicit excluded platforms and future milestones in ROADMAP.md"
Task: "T020 [P] [US1] Write security policy covering secrets, credentials, raw agent tokens, and reporting in SECURITY.md"
Task: "T021 [P] [US1] Write contribution guide covering small PRs, validation, docs updates, and constitution alignment in CONTRIBUTING.md"
```

## Parallel Example: User Story 2

```text
Task: "T024 [P] [US2] Create minimal marketing site app files in apps/site/app/page.tsx, apps/site/next.config.js, and apps/site/tsconfig.json"
Task: "T025 [P] [US2] Create minimal product dashboard app files in apps/dashboard/app/page.tsx, apps/dashboard/next.config.js, and apps/dashboard/tsconfig.json"
Task: "T026 [P] [US2] Document command placeholder behavior and non-goals in cmd/api/README.md, cmd/agent/README.md, and cmd/cli/README.md"
```

## Parallel Example: User Story 3

```text
Task: "T030 [P] [US3] Define AgentEvent, event source, event level, and event category contracts in pkg/contracts/events.go"
Task: "T031 [P] [US3] Define scanner request, result, runtime, service requirement, finding, and status contracts in pkg/contracts/scanner.go"
Task: "T032 [P] [US3] Define diagnosis check, target, finding, severity, status, and recommendation contracts in pkg/contracts/diagnosis.go"
Task: "T035 [P] [US3] Define machine-readable error contract and retryability fields in pkg/contracts/errors.go"
```

## Parallel Example: User Story 4

```text
Task: "T038 [P] [US4] Create bug report issue template in .github/ISSUE_TEMPLATE/bug_report.yml"
Task: "T039 [P] [US4] Create feature request issue template in .github/ISSUE_TEMPLATE/feature_request.yml"
Task: "T040 [P] [US4] Create pull request checklist template in .github/pull_request_template.md"
```

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1 setup.
2. Complete Phase 2 foundational repository areas.
3. Complete Phase 3 User Story 1 root documentation and license.
4. Stop and validate that contributors can understand the project foundation from root docs.

### Incremental Delivery

1. Deliver Setup + Foundational structure.
2. Deliver US1 documentation MVP.
3. Deliver US2 navigable repository areas.
4. Deliver US3 shared contracts.
5. Deliver US4 GitHub templates and CI skeleton.
6. Run Phase 7 polish validation.

### Parallel Team Strategy

After Phase 2, separate contributors can own US1 docs, US2 structure/app placeholders, US3 contracts, and US4 GitHub metadata independently because each story writes mostly disjoint files.

## Notes

- Keep all backend/control-plane code Go-only.
- Keep Next.js limited to `apps/site` and `apps/dashboard`.
- Do not implement agent registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud execution.
- Do not add secrets, credentials, raw agent tokens, or destructive server commands.
- Commit after each completed phase or logical task group.

## Completion Notes

- Completed on 2026-06-04.
- `go test ./...` passed.
- Scope scan found only documentation/specification references to excluded behavior, not runtime implementations.
- No deviations from the implementation plan were required.
