# Feature Specification: Instancr Foundation Monorepo

**Feature Branch**: `001-foundation-monorepo`

**Created**: 2026-06-04

**Status**: Draft

**Input**: User description: "Create the Instancr foundation monorepo as a Go-first open-source deployment control plane, including repository structure, website and dashboard app areas, Go API/agent/CLI entrypoints, internal packages, shared contracts, documentation folders, infrastructure folders, examples, project documents, GitHub templates, and a CI skeleton. Define initial event, scanner, diagnosis, server, agent, deployment, and error contracts. Do not implement registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud implementation."

## Clarifications

### Session 2026-06-04

- Q: Which open-source license should the foundation repository use? → A: Apache-2.0

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Understand the Project Foundation (Priority: P1)

A new contributor can open the repository and immediately understand that Instancr is an open-source deployment control plane with a Go-first backend, separate website and dashboard workspaces, shared contracts, examples, infrastructure placeholders, and contributor-facing documentation.

**Why this priority**: The foundation must make the project purpose, boundaries, and contribution path obvious before any product behavior is implemented.

**Independent Test**: Can be fully tested by inspecting the repository root and documentation files, confirming that the purpose, scope, non-goals, contribution expectations, security posture, and roadmap are discoverable without prior project knowledge.

**Acceptance Scenarios**:

1. **Given** a fresh checkout of the repository, **When** a contributor reviews the root files, **Then** they find README, SPEC, AGENTS, ROADMAP, BUILD-IN-PUBLIC, SECURITY, CONTRIBUTING, LICENSE, and governance-relevant guidance.
2. **Given** a contributor wants to understand what Instancr will and will not build in the foundation, **When** they read the specification and roadmap documents, **Then** they see the Go-first, AI-independent, AWS EC2-focused v1 boundaries and excluded platforms clearly stated.

---

### User Story 2 - Navigate Required Project Areas (Priority: P2)

A maintainer can verify that the repository has the required monorepo areas for product apps, command entrypoints, internal packages, public contracts, documentation, infrastructure placeholders, and examples.

**Why this priority**: The repository shape is the primary deliverable for this feature and should guide future implementation without requiring later restructuring.

**Independent Test**: Can be fully tested by listing directories and confirming each required area exists with minimal placeholder content where appropriate.

**Acceptance Scenarios**:

1. **Given** the foundation repository exists, **When** a maintainer lists top-level project areas, **Then** they find `apps`, `cmd`, `internal`, `pkg`, `docs`, `infra`, `examples`, and `.github`.
2. **Given** a maintainer inspects command areas, **When** they open the API, server agent, and CLI entrypoints, **Then** each has a minimal placeholder that identifies the future executable purpose without implementing product workflows.
3. **Given** a maintainer inspects internal package areas, **When** they review the package tree, **Then** each requested domain area exists for API, config, database, servers, agents, events, deployments, telemetry, scanner, doctor, cloud/aws, docker, and caddy.

---

### User Story 3 - Establish Shared Contracts (Priority: P3)

A future component owner can reference initial shared contracts for events, scanning, diagnosis, servers, agents, deployments, and errors before product features are implemented.

**Why this priority**: Early contracts reduce ambiguity across the API, agent, CLI, dashboard, scanner, and diagnostics work planned later.

**Independent Test**: Can be fully tested by reviewing the shared contract package and confirming each requested contract category has an initial typed definition with names and fields sufficient for future planning.

**Acceptance Scenarios**:

1. **Given** the shared contract package exists, **When** a component owner reviews it, **Then** they find an AgentEvent contract with timestamp, source, level, category, code, message, server identifier, and metadata concepts represented.
2. **Given** the shared contract package exists, **When** scanner and doctor owners review it, **Then** they find initial scanner and diagnosis contracts without requiring AI or external service calls.
3. **Given** the shared contract package exists, **When** product and control-plane owners review it, **Then** they find server, agent, deployment, and error contracts with machine-readable identifiers and human-readable descriptions.

---

### User Story 4 - Prepare Open-Source Collaboration Checks (Priority: P4)

A contributor can open issues or pull requests using templates, and maintainers can rely on an initial continuous integration workflow to guard the foundation from obvious breakage.

**Why this priority**: Open-source quality requires repeatable contribution intake and basic validation from the first repository state.

**Independent Test**: Can be fully tested by inspecting GitHub templates and CI workflow definitions, then running the available local checks documented by the repository.

**Acceptance Scenarios**:

1. **Given** a contributor wants to report a bug, request a feature, or open a pull request, **When** they inspect the GitHub metadata, **Then** issue templates and a pull request template are available.
2. **Given** a maintainer reviews repository automation, **When** they inspect the CI workflow, **Then** it includes a skeleton for validating the initial foundation without deploying infrastructure or contacting AI services.

### Edge Cases

- If a required product area is intentionally a placeholder, the placeholder must clearly state its future purpose and must not imply that the related feature is already implemented.
- If a future-facing package exists for an out-of-scope integration, it must remain empty or placeholder-only and must not perform real external operations.
- If documentation references future capabilities, it must distinguish roadmap intent from implemented functionality.
- If contract names overlap with future product domains, the foundation must keep them minimal and stable enough for planning without overcommitting to final behavior.
- If CI runs before product code exists, it must still succeed by validating available placeholders and repository hygiene rather than expecting unavailable services.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: Repository MUST contain a Go-first monorepo structure with clearly separated areas for product apps, command entrypoints, internal packages, shared contracts, documentation, infrastructure placeholders, examples, and GitHub metadata.
- **FR-002**: Repository MUST initialize a Go module for the control-plane foundation.
- **FR-003**: Repository MUST include `apps/site` for the marketing website workspace and `apps/dashboard` for the product dashboard workspace.
- **FR-004**: Website and dashboard workspaces MUST be initialized as Next.js app areas with minimal placeholder content and project metadata.
- **FR-005**: Repository MUST include minimal command entrypoints at `cmd/api`, `cmd/agent`, and `cmd/cli`, each identifying its intended future executable role.
- **FR-006**: Repository MUST include internal package areas for API, config, database, servers, agents, events, deployments, telemetry, scanner, doctor, cloud/aws, docker, and caddy.
- **FR-007**: Repository MUST include `pkg/contracts` as the shared contract package for cross-component data definitions.
- **FR-008**: Shared contracts MUST define an AgentEvent contract with timestamp, source, level, category, code, message, server identifier, and metadata concepts.
- **FR-009**: Shared contracts MUST define scanner contracts that can represent repository scan requests, results, findings, detected runtimes, and service requirements.
- **FR-010**: Shared contracts MUST define diagnosis contracts that can represent diagnostic checks, findings, severity, recommended action, and machine-readable codes.
- **FR-011**: Shared contracts MUST define server, agent, deployment, and error contracts with stable identifiers and human-readable status or message fields.
- **FR-012**: Repository MUST include documentation folders for product, architecture, decisions, and runbooks.
- **FR-013**: Repository MUST include infrastructure folders for docker, compose, and aws without implementing real Docker deployment, Caddy setup, or AWS integration behavior.
- **FR-014**: Repository MUST include example folders for node-express, nextjs, and nestjs-postgres without treating those examples as backend services for the control plane.
- **FR-015**: Repository MUST include README.md, SPEC.md, AGENTS.md, ROADMAP.md, BUILD-IN-PUBLIC.md, SECURITY.md, CONTRIBUTING.md, and an Apache-2.0 LICENSE at the repository root.
- **FR-016**: GitHub metadata MUST include issue templates and a pull request template suitable for open-source contribution intake.
- **FR-017**: GitHub Actions metadata MUST include a CI workflow skeleton for validating the initial foundation.
- **FR-018**: Foundation MUST NOT implement agent registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI or LLM calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud implementation.
- **FR-019**: Foundation documentation and placeholders MUST explicitly preserve the constitution boundaries: Go-first backend, deterministic-first intelligence, AWS EC2-focused v1, structured event expectations, production confidence, security first, and open-source quality.
- **FR-020**: Foundation MUST provide enough placeholder content for each required directory that empty folders are preserved in version control where needed.

### Key Entities

- **Repository Area**: A named workspace or folder that represents a future product, runtime, internal domain, documentation area, infrastructure area, example, or project metadata area.
- **Command Entrypoint**: A minimal executable placeholder representing the future API service, server agent, or CLI without implementing product workflows.
- **Shared Contract**: A public data definition intended for use across future API, agent, CLI, dashboard, scanner, doctor, deployment, and telemetry work.
- **AgentEvent**: A structured event emitted by future control-plane or agent actions, including source, level, category, code, message, server identifier, timestamp, and metadata.
- **Scanner Contract**: A shared definition describing repository scan inputs, detected application characteristics, findings, and service requirements.
- **Diagnosis Contract**: A shared definition describing checks, findings, severity, actionable recommendations, and machine-readable diagnosis codes.
- **Documentation Artifact**: A root or docs-folder document that explains product intent, architecture, decisions, runbooks, contribution, roadmap, security, or public build notes.
- **CI Workflow**: A repository automation definition that records the intended validation path for the foundation.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A new contributor can identify the project purpose, v1 scope, non-goals, contribution process, security policy, and roadmap from root documentation in under 10 minutes.
- **SC-002**: A maintainer can verify 100% of required repository areas from the feature request by inspecting the filesystem in under 5 minutes.
- **SC-003**: A component owner can identify initial shared contracts for all requested contract categories with no missing category.
- **SC-004**: Foundation validation can complete without requiring cloud credentials, deployed infrastructure, paid external services, AI API keys, or production secrets.
- **SC-005**: The initial repository contains zero implemented out-of-scope runtime workflows for agent registration, heartbeat, AWS integration, Docker deployment, Caddy setup, AI calls, Kubernetes, ECS, EKS, Lambda, Terraform export, billing, or multi-cloud execution.
- **SC-006**: At least one issue template, one pull request template, one CI workflow skeleton, and Apache-2.0 license text are present for open-source collaboration from the initial foundation.

## Assumptions

- This feature establishes the repository foundation only; product behavior will be specified and implemented in later features.
- Go is the required foundation language for API, agent, CLI, scanner, doctor, cloud integration, and deployment orchestration areas because the project constitution mandates a Go-first backend.
- Next.js is permitted only for the marketing website and product dashboard workspaces.
- Placeholder package areas for future AWS, Docker, and Caddy work are allowed only if they do not implement real integration or deployment behavior in this feature.
- Example applications may use non-Go application stacks because they represent deployable user workloads, not Instancr backend services.
- PostgreSQL, Docker, and Caddy may be referenced as future project direction, but this foundation does not provision or operate them.
- The repository uses Apache-2.0 as its initial open-source license.
