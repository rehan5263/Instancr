# Research: Instancr Foundation Monorepo

## Decision: Use a Go root module for the control-plane foundation

**Rationale**: The constitution requires Go for API, server agent, CLI, scanner, doctor, cloud integrations, and deployment orchestration. A root Go module keeps the control-plane source easy to validate with `go test ./...` and makes `cmd/*`, `internal/*`, and `pkg/contracts` idiomatic.

**Alternatives considered**: A language-agnostic root with separate backend package was rejected because it weakens the Go-first constraint. A Node.js backend workspace was rejected by the constitution.

## Decision: Keep Next.js limited to `apps/site` and `apps/dashboard`

**Rationale**: The project needs a marketing site and product dashboard, and the constitution explicitly reserves Next.js for those two surfaces. Initial app placeholders should be minimal and should not include backend control-plane behavior.

**Alternatives considered**: A single combined frontend was rejected because marketing and product dashboard concerns will diverge. Additional JavaScript backend services were rejected by the Go-first rule.

## Decision: Create placeholder-only infra folders for AWS, Docker, Compose, and Caddy

**Rationale**: The feature requires those folders, but the spec prohibits AWS integration, Docker deployment, and Caddy setup. Placeholder documentation preserves future structure without creating runtime behavior outside the accepted scope.

**Alternatives considered**: Implementing sample AWS or Docker workflows was rejected because it would violate the feature non-goals. Omitting folders was rejected because the acceptance criteria require them.

## Decision: Define shared contracts in `pkg/contracts`

**Rationale**: Contract definitions need to be available across future API, agent, CLI, dashboard, scanner, doctor, deployment, and telemetry work. A public Go package is the correct location for stable cross-component data contracts in a Go-first project.

**Alternatives considered**: Keeping contracts under `internal` was rejected because dashboard/API/CLI boundary contracts need a stable shared location. Generating OpenAPI first was rejected because no HTTP API behavior is implemented in this foundation.

## Decision: Use Apache-2.0 licensing

**Rationale**: The clarification session selected Apache-2.0. It is permissive and includes an explicit patent grant, which is appropriate for open-source infrastructure/control-plane software.

**Alternatives considered**: MIT was considered but lacks the same patent grant. MPL-2.0 and AGPL-3.0 were considered but impose stronger file-level or network copyleft obligations than desired for the foundation.

## Decision: CI skeleton validates local repository health without external credentials

**Rationale**: The foundation must be verifiable before runtime features exist. CI should run basic Go validation and repository hygiene checks without cloud credentials, deployed infrastructure, AI keys, or secrets.

**Alternatives considered**: Provisioning cloud resources or running deployment smoke tests was rejected because AWS/Docker/Caddy deployment behavior is out of scope.

## Decision: Use placeholder files to retain empty directories

**Rationale**: Git does not track empty directories. Minimal placeholder files let the required structure exist while clearly marking future package and infrastructure areas as non-implemented.

**Alternatives considered**: Leaving directories empty would fail repository-structure acceptance criteria after commit. Filling each package with real behavior would exceed the foundation scope.
