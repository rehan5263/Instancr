# Server Agent Command

Future Go server agent entrypoint.

Current status: placeholder only. It does not register itself, send heartbeat data, run commands, or manage host state.
