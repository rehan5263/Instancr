package main

import "fmt"

func main() {
	fmt.Println("Instancr server agent placeholder: no agent workflows are implemented yet.")
}
