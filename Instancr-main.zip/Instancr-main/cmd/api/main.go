package main

import "fmt"

func main() {
	fmt.Println("Instancr API placeholder: no server workflows are implemented yet.")
}
