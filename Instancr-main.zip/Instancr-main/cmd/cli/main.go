package main

import "fmt"

func main() {
	fmt.Println("Instancr CLI placeholder: no deployment commands are implemented yet.")
}
