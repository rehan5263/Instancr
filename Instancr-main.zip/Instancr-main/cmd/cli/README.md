# CLI Command

Future Go CLI entrypoint.

Current status: placeholder only. It does not deploy applications, call cloud APIs, or mutate remote infrastructure.
