export default function Page() {
  return (
    <main>
      <h1>Instancr</h1>
      <p>Marketing site placeholder for the Go-first deployment control plane.</p>
    </main>
  );
}
