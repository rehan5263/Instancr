export default function Page() {
  return (
    <main>
      <h1>Instancr Dashboard</h1>
      <p>Product dashboard placeholder. Control-plane workflows are not implemented yet.</p>
    </main>
  );
}
