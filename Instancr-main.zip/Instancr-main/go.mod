module github.com/instancr/instancr

go 1.25.1
