# Security Policy

## Current Status

The repository currently contains foundation placeholders only. It does not operate servers, store credentials, execute deployment commands, or connect to cloud APIs.

## Security Rules

- Do not commit secrets, credentials, raw tokens, private keys, or production environment files.
- Do not log raw server agent tokens or credentials in future work.
- Do not add destructive server commands without explicit user confirmation flows.
- Keep the server agent minimal, auditable, and Go-based.
- Keep AI and LLM calls out of v1 implementation.

## Reporting

Open a private security report through the repository security advisory process when available. Until then, avoid posting exploitable details in public issues.
